<div class="container-fluid mt-3">
    <ul class="nav nav-tabs">
        <li class="nav-item">
            <a class="nav-link active" role="tab" data-toggle="tab" href="#customer">Customer</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" role="tab" data-toggle="tab" href="#restaurant">Restaurant</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" role="tab" data-toggle="tab" href="#reservation">Reservation</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" role="tab" data-toggle="tab" href="#login">Login</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" role="tab" data-toggle="tab" href="#staff">Staff</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" role="tab" data-toggle="tab" href="#admin">Admin</a>
        </li>
    </ul>
    <div class="tab-content">
        <div role ="tabpanel" class="tab-pane active" id = "customer">
            <div class="table-wrapper-scroll-y my-custom-scrollbar mt-3">
                <table id="table" class="table table-bordered table-striped text-center" style="height: 800px">
                    <tr>
                        <th>id</th>
                        <th>Login Id</th>
                        <th>First Name</th>
                        <th>Middle Name</th>
                        <th>Last Name</th>
                        <th>Contact Number</th>
                        <th>Address1</th>
                        <th>Barangay</th>
                        <th>City</th>
                        <th>Province</th>
                        <th>Date Added</th>
                        <th>Actions</th>
                    </tr>
                    <?php
                        require_once "customertable.php";
                    ?>
                </table>
            </div>
        </div>
        <div role ="tabpanel" class="tab-pane" id = "restaurant">
            <div class="table-wrapper-scroll-y my-custom-scrollbar mt-3">
                <table id="table" class="table table-bordered table-striped text-center" style="height: 800px">
                    <tr>
                        <th>Id</th>
                        <th>Login Id</th>
                        <th>Restaurant Name</th>
                        <th>First Name</th>
                        <th>Middle Name</th>
                        <th>Last Name</th>
                        <th>Contact Number</th>
                        <th>Address1</th>
                        <th>Barangay</th>
                        <th>City</th>
                        <th>Province</th>
                        <th>Status</th>
                        <th>Date Added</th>
                        <th>Actions</th>
                    </tr>
                    <?php
                        require_once "restauranttable.php";
                    ?>
                </table>
            </div>
        </div>
        <div role ="tabpanel" class="tab-pane mx-auto" id = "reservation">
            <div class="table-wrapper-scroll-y my-custom-scrollbar mt-3">
                <table id="table" class="table table-bordered table-striped text-center" style="height: 800px">
                    <tr>
                        <th>Id</th>
                        <th>Restaurant Id</th>
                        <th>Customer Id</th>
                        <th>Date</th>
                        <th>Time</th>
                        <th>Seats</th>
                        <th>Status</th>
                        <th>Feedback</th>
                        <th>Date Added</th>
                        <th>Actions</th>
                    </tr>
                    <?php
                        require_once "reservationtable.php";
                    ?>
                </table>
            </div>
        </div>
        <div role ="tabpanel" class="tab-pane mx-auto" id = "login">
            <div class="table-wrapper-scroll-y my-custom-scrollbar mt-3">
                <table id="table" class="table table-bordered table-striped text-center" style="height: 800px">
                    <tr>
                        <th>id</th>
                        <th>Username</th>
                        <th>Password</th>
                        <th>Email</th>
                        <th>VKey</th>
                        <th>Verified</th>
                        <th>Type</th>
                        <th>Date Added</th>
                        <th>Actions</th>
                    </tr>
                    <?php
                        require_once "logintable.php";
                    ?>
                </table>
            </div>
        </div>
        <div role ="tabpanel" class="tab-pane" id = "staff">
            <div class="table-wrapper-scroll-y my-custom-scrollbar mt-3">
                <table id="table" class="table table-bordered table-striped text-center" style="height: 800px">
                    <tr>
                        <th>Id</th>
                        <th>Restaurant Id</th>
                        <th>Username</th>
                        <th>Password</th>
                        <th>First Name</th>
                        <th>Last Name</th>
                        <th>Contact Number</th>
                        <th>Status</th>
                        <th>Date Added</th>
                        <th>Actions</th>
                    </tr>
                    <?php
                        require_once "stafftable.php";
                    ?>
                </table>
            </div>
        </div>
        <div role ="tabpanel" class="tab-pane mx-auto" id = "admin" style="width:600px">
            <div class="table-wrapper-scroll-y my-custom-scrollbar mt-3">
                <table id="table" class="table table-bordered table-striped text-center" style="height: 800px">
                    <tr>
                        <th>id</th>
                        <th>Username</th>
                        <th>Password</th>
                        <th>Name</th>
                        <th>Actions</th>
                    </tr>
                    <?php
                        require_once "admintable.php";
                    ?>
                </table>
            </div>
        </div>        
    </div>
    
</div>