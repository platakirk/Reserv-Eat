<?php
session_start();
$title = 'Main page';
require_once 'includes/header.php';
require_once 'includes/nav.php';
require_once 'connection.php';

// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: welcome.php");
    exit;
} 

if(isset($_GET["id"])){
    $id = $_GET["id"];
    $sql = "SELECT * FROM restaurant WHERE id = $id";
    if($result = $conn->query($sql)){
        if($result->num_rows > 0){
        $row = $result->fetch_assoc();
        $rname = $row["restaurantName"];
        $address = $row["city"];
        $desc = $row["description"];
        }
    }
}
?>
<div class="container">
    <div class="row">
        <div class="col-8">
            <h2 class="pl-3"><?=$rname?></h2>
            <div class="jumbotron jumbotron-fluid pt-3 pl-3">
                <h5>ABOUT AREA</h5>
                <br>
                <h6>tags:
                <?php 
                    $sql = "SELECT * FROM tag WHERE resId = $id";
                    if($result = $conn->query($sql)){
                        if($result->num_rows > 0){        
                            while($row = $result->fetch_assoc()){
                                $tag = $row["tagName"]; ?>
                                <button type="button" class="btn btn-outline-primary btn-sm" disabled><?= $tag ?></button>
                                <?php
                            }
                        }
                    }
                ?>
                </h6>
                <hr>
                <h1>MENU AREA</h1>
            </div>
        </div>
        <div class="col-4 mt-5">
            <div class="jumbotron jumbotron-fluid pt-4">
                <div class="container">
                    <h5>Reservation details</h5>
                    <hr>
                    <form action="landing.php" method="POST">
                            <input type="hidden" id="rid" name ="rid" value="<?= $id?>">
                        <div class="form-group">
                            <label for="date">Date</label>
                            <input type="date" class="form-control" id="date" name="date" >
                        </div>
                        <div class="form-group">
                            <label for="time">Time</label>
                            <input type="time" class="form-control" id="time" name="time">
                        </div>
                        <div class="form-group">
                            <label for="seat">Seats</label>
                            <input type="number" min="1"class="form-control" id="seat" name="seat" placeholder="Number of Seats">
                        </div>           
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-primary" name="resbtn">Reserve</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>


<?php require_once 'includes/footer.php'; ?>