<?php
  session_start();
  if(isset($_SESSION['loginId'])){
    $to = $_SESSION["email"];
    $vkey = $_SESSION["vkey"];
    $u = $_SESSION["username"];
    $subject = "Email Verification";
    $message = "<a href = 'http://localhost/isproj/verify.php?vkey=$vkey'>Register Account</a><br>
              Username: $u";
    $headers = "From: officialreserv.eat@gmail.com \r\n";
    $headers .= "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

    if(mail($to, $subject,$message, $headers)){
    header("location: thankyou.php");
  }
  }
  
?>