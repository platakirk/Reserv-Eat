<?php

if(isset($_SESSION['resId'])){
    $id = $_SESSION['resId'];
    $sql = "SELECT id, menucat.category, menuitem.name as iname, menuitem.price FROM menucat INNER JOIN menuitem on menuitem.catId = menucat.id WHERE resId= $id ORDER BY menucat.category, menuitem.name";

                    if($result = $conn->query($sql)){
                        if($result->num_rows > 0){
                        while($row = $result->fetch_assoc()) { ?>                        
                            <tr>
                                <td><?php echo $row["category"] ?> </td>                            
                                <td><?php echo $row["iname"] ?> </td>
                                <td><?php echo $row["price"] ?> </td>
                                <td>
                                    <a href="#" class="btn btn-success">Edit</a><br><br>
                                    <a href="#" class="btn btn-danger">Delete</a>
                                </td>
                            </tr>
                        <?php }
                    }
                $result->close();      
            }
        }

?>