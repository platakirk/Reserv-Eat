<nav class="navbar navbar-expand-lg sticky-top navbar-dark" style = "background-color: #0075e2">
  <div class="container col-md-12">
    <a class="navbar-brand" href="landing.php"><img src= "images/logo.png"></a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav ml-auto">
        <li class="nav-item">
          <a class="nav-link" href="landing.php">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="staff/staffLogout.php">Signout</a>
        </li>
      </ul>
    </div>
  </div>
</nav>